//
//  FLEXArgumentInputColorView.h
//  Flipboard
//
//  Created by Ryan Olson on 6/30/14.
//  Copyright (c) 2014 Flipboard. All rights reserved.
//

#import "FLEXArgumentInputView.h"

@interface FLEXArgumentInputColorView : FLEXArgumentInputView

@end
